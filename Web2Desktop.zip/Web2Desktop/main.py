import sys
import os
import subprocess
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QLabel, QLineEdit,
    QPushButton, QVBoxLayout, QWidget, QMessageBox
)

class Web2Desktop(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Web2Desktop Builder")
        self.setGeometry(100, 100, 400, 250)

        layout = QVBoxLayout()

        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("App Name")
        layout.addWidget(QLabel("App Name:"))
        layout.addWidget(self.name_input)

        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("Website URL")
        layout.addWidget(QLabel("Website URL:"))
        layout.addWidget(self.url_input)

        self.button = QPushButton("Generate App")
        self.button.clicked.connect(self.generate_app)
        layout.addWidget(self.button)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def generate_app(self):
        name = self.name_input.text().strip()
        url = self.url_input.text().strip()

        if not name or not url:
            QMessageBox.warning(self, "Missing Info", "Please enter both name and URL.")
            return

        safe_name = name.replace(" ", "_")
        filename = f"{safe_name}.py"

        code = f'''
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtCore import QUrl

class WebApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("{name}")
        self.setGeometry(100, 100, 1000, 800)
        browser = QWebEngineView()
        browser.load(QUrl("{url}"))
        self.setCentralWidget(browser)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = WebApp()
    window.show()
    sys.exit(app.exec_())
'''

        try:
            with open(filename, "w", encoding="utf-8") as f:
                f.write(code)

            pyinstaller_path = r"C:\Program Files\Python313\Scripts\pyinstaller.exe"
            if not os.path.exists(pyinstaller_path):
                QMessageBox.critical(self, "Error", "PyInstaller not found at expected path.")
                return

            subprocess.run([
                pyinstaller_path,
                "--noconfirm",
                "--onefile",
                "--windowed",
                filename
            ])

            QMessageBox.information(self, "Success", f"✅ '{safe_name}.exe' was created in the 'dist' folder.")
        except Exception as e:
            QMessageBox.critical(self, "Build Failed", str(e))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Web2Desktop()
    window.show()
    sys.exit(app.exec_())