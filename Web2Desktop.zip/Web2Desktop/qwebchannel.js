(function () {
  if (typeof qt === 'undefined') {
    console.error("❌ Qt WebChannel transport not found.");
    return;
  }

  function QWebChannel(transport, callback) {
    const channel = this;
    this.transport = transport;
    this.objects = {};

    transport.onmessage = function (event) {
      const message = JSON.parse(event.data);
      if (message.type === "init") {
        for (const name in message.objects) {
          const obj = {};
          for (const method of message.objects[name].methods) {
            obj[method] = function () {
              const args = Array.from(arguments);
              transport.send(JSON.stringify({
                type: "invoke",
                object: name,
                method: method,
                args: args
              }));
            };
          }
          channel.objects[name] = obj;
        }
        callback(channel);
      }
    };

    transport.send(JSON.stringify({ type: "init" }));
  }

  window.QWebChannel = QWebChannel;
})();